 <!-- jQuery -->
 <script src="./public/temp/admin/plugins/jquery/jquery.min.js"></script>
 <!-- Bootstrap 4 -->
 <script src="./public/temp/admin/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
 <!-- AdminLTE App -->
 <script src="./public/temp/admin/dist/js/adminlte.min.js"></script>
 <script src="./public/temp/admin/dist/js/jquery.validate.min.js"></script>
 <!-- <script src="./public/js/script.js"></script> -->
 <script src="./public/js/validate.js"></script>
 <script>
   var domainUrl = "<?php echo TFO_DOMAIN . TFO_INDEX ?>";
 </script>
 </body>

 </html>