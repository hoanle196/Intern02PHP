<?php
class AdminController extends Hooks
{
  public function index()
  {
    if (isset($_GET['searchSubmit'])) {
      $model = $this->model('AdminModel');
      $data = $model->getBySearch($_GET);
    } else {
      $model = $this->model('AdminModel');
      $data = $model->getListRoomModel();
    }
    $this->title = 'Motel Home';
    $this->content = $this->view('Client.index', compact('data'));
    $this->layout('client');
  }

  public function detailRoom()
  {
    $this->title = 'details Home';
    $model = $this->model('AdminModel');
    $data = $model->getListRoomModel($_GET['id']);
    $this->content = $this->view('Client.details', compact('data'));
    $this->layout('client');
  }

  public function dashboard()
  {
    $this->title = 'Admin dashboard';
    $this->content = $this->view('Admin-motel.index');
    $this->layout('admin');
  }

  public function createRoom()
  {
    $model = $this->model('AdminModel');
    $data = $model->getListAttribute();
    $this->title = 'Admin dashboard';
    $this->content = $this->view('Admin-motel.create-room', compact('data'));
    $this->layout('admin');
  }

  public function saveRoom()
  {
    $model = $this->model('AdminModel');
    if (!($model->saveRoomModel($_POST, $_FILES))) {
      return Alert::notification([
        "status" => "error",
        "message" => "add fail",
        "location" => "&a=listRoom",
      ]);
    }
    Alert::notification([
      "status" => "success",
      "message" => "add success fully",
      "location" => "&a=listRoom",
    ]);
  }

  public function listRoom()
  {
    $model = $this->model('AdminModel');
    $result = $model->getListRoomModel();
    $this->title = 'list room';
    $this->content = $this->view('Admin-motel.list-room', compact('result'));
    $this->layout('admin');
  }

  public function editRoom()
  {
    $model = $this->model('AdminModel');
    $data = $model->getListRoomModel($_GET['id']);
    $attr = $model->getListAttribute();
    $image = $this->getDataImage($_GET['id']);
    $this->title = 'edit room';
    $this->content = $this->view('Admin-motel.edit-room', compact('data', 'attr', 'image'));
    $this->layout('admin');
  }
  public function updateRoom()
  {
    $model = $this->model('AdminModel');
    if (!($model->updateRoomModel($_POST, $_FILES, $_GET['id']))) {
      return Alert::notification([
        "status" => "error",
        "message" => "edit fail",
        "location" => "&a=listAttribute",
      ]);
    }
    Alert::notification([
      "status" => "success",
      "message" => "edit success",
      "location" => "&a=listRoom",
    ]);
  }

  public function destroyRoom()
  {
    if (!($this->destroyWithId('rooms', $_GET['id']))) {
      return Alert::notification([
        "status" => "error",
        "message" => "delete fail",
        "location" => "&a=listRoom",
      ]);
    }
    Alert::notification([
      "status" => "success",
      "message" => "delete success",
      "location" => "&a=listRoom",
    ]);
  }

  public function createAttribute()
  {
    $this->title = 'attribute dashboard';
    $this->content = $this->view('Admin-motel.create-attribute');
    $this->layout('admin');
  }

  public function addAttribute()
  {
    $model = $this->model('AdminModel');
    if ($model->addAttributeModel($_POST)) {
      Alert::notification([
        "status" => "success",
        "message" => "add success fully",
        "location" => "&a=listAttribute",
      ]);
    }
  }

  public function listAttribute()
  {
    $model = $this->model('AdminModel');
    $result = $model->getListAttribute();

    $this->title = 'attribute list';
    $this->content = $this->view('Admin-motel.list-attribute', compact('result'));
    $this->layout('admin');
  }

  public function editAttr()
  {
    $result = $this->fetchOneInTable('attributes', $_GET['id']);
    $this->title = 'edit attribute';
    $this->content = $this->view('Admin-motel.edit-attribute', compact('result'));
    $this->layout('admin');
  }

  public function updateAttr()
  {
    $model = $this->model('AdminModel');
    if (!($model->updateAttr($_POST, $_GET['id']))) {
      return Alert::notification([
        "status" => "error",
        "message" => "edit fail",
        "location" => "&a=listAttribute",
      ]);
    }
    Alert::notification([
      "status" => "success",
      "message" => "edit success",
      "location" => "&a=listAttribute",
    ]);
  }

  public function destroyAttr()
  {
    if (!($this->destroyWithId('attributes', $_GET['id']))) {
      return Alert::notification([
        "status" => "error",
        "message" => "delete fail",
        "location" => "&a=listAttribute",
      ]);
    }
    Alert::notification([
      "status" => "success",
      "message" => "delete success",
      "location" => "&a=listAttribute",
    ]);
  }















  public function ApiGetDataDistrict()
  {
    $this->getDataDistrict($_GET);
  }
  public function ApiGetDataWard()
  {
    $this->getDataWard($_GET);
  }









  public function logout()
  {
    unset($_SESSION['login']);
    Alert::notification([
      'status' => 'success',
      'message' => 'logout successfully',
      'location' => 'authentication&a=index',
    ]);
  }

  public function canManageOrders()
  {
    return true;
  }

  public function canManageCustomers()
  {
    return true;
  }
}
