<?php
class UserController
{
  protected $name;
  protected $email;

  public function __construct($name = null, $email = null)
  {
    if ($name) {
      $this->name = $name;
      $this->email = $email;
    }
  }
  public function index()
  {
    // unset($_SESSION['success']);
    // unset($_SESSION['login']);
    echo "usser index";
    var_dump($_SESSION);
  }
  public function getName()
  {
    return $this->name;
  }

  public function getEmail()
  {
    return $this->email;
  }
}
