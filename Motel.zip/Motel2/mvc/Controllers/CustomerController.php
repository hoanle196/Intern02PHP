<?php
class CustomerController extends Hooks
{
  public function index()
  {
    if (isset($_GET['searchSubmit'])) {
      $model = $this->model('AdminModel');
      $data = $model->getBySearch($_GET);
    } else {
      $model = $this->model('AdminModel');
      $data = $model->getListRoomModel();
    }
    $this->title = 'Motel Home';
    $this->content = $this->view('Client.index', compact('data'));
    $this->layout('client');
  }

  public function detailRoom()
  {
    $this->title = 'details Home';
    $model = $this->model('AdminModel');
    $data = $model->getListRoomModel($_GET['id']);
    $this->content = $this->view('Client.details', compact('data'));
    $this->layout('client');
  }

  // public function canViewDetails()
  // {
  //   $this->title = 'details Motel';
  //   $this->content = $this->view('Client.details');
  //   $this->layout('client');
  // }

  public function logout()
  {
    unset($_SESSION['login']);
    Alert::notification([
      'status' => 'success',
      'message' => 'logout successfully',
      'location' => 'authentication&a=index',
    ]);
  }

  public function canViewProfile()
  {
    return true;
  }


  public function canUpdateProfile()
  {
    return true;
  }

  public function booking()
  {
    $this->title = 'order Motel';
    $this->content = $this->view('Client.order');
    $this->layout('client');
  }

  public function canCreateOrder()
  {
  }

  public function canUpdateOrder()
  {
    return true;
  }

  public function canCancelOrder()
  {
    return true;
  }

  public function ApiGetDataDistrict()
  {
    $this->getDataDistrict($_GET);
  }
  public function ApiGetDataWard()
  {
    $this->getDataWard($_GET);
  }
}
