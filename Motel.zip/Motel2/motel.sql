/*
 Navicat Premium Data Transfer

 Source Server         : DBhoanle
 Source Server Type    : MariaDB
 Source Server Version : 100417
 Source Host           : localhost:3306
 Source Schema         : motel

 Target Server Type    : MariaDB
 Target Server Version : 100417
 File Encoding         : 65001

 Date: 23/02/2023 07:31:43
*/

