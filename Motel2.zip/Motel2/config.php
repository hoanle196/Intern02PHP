<?php
define('TFO_VERSION', '1.0.0');
define('TFO_SERVER_NAME', 'localhost');
define('TFO_DATABASE_NAME', 'motel');
define('TFO_USERNAME', 'root');
define('TFO_PASSWORD', '');

define('TFO_INDEX', $_SERVER['PHP_SELF']);
define('TFO_DOMAIN', $_SERVER['HTTP_HOST']);
define('TFO_URI', $_SERVER['REQUEST_URI']);

// echo '<script>var ajaxUrl = "' . TFO_DOMAIN . TFO_INDEX . '"</script>';
// echo "<script>var ajaxUrl = '" . TFO_DOMAIN . TFO_INDEX . "'</script>";
