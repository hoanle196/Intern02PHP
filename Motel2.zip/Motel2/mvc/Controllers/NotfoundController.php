<?php
class NotfoundController
{

  public function index()
  {
    echo 'tai khoan cua ban bi khoa';
  }
}
