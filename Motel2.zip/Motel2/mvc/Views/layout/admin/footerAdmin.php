<script src="./public/temp/admin/plugins/jquery/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js" integrity="sha512-rstIgDs0xPgmG6RX1Aba4KV5cWJbAMcvRCVmglpam9SoHZiUCyQVDdH2LPlxoHtrv17XWblE/V/PP+Tr04hbtA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<!-- Bootstrap 4 -->
<script src="./public/temp/admin/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="./public/temp/admin/dist/js/adminlte.min.js"></script>
<script src="./public/temp/admin/dist/js/jquery.validate.min.js"></script>
<script src="./public/js/script.js"></script>
<script src="./public/js/validate.js"></script>
<script>
  var domainUrl = "<?php echo TFO_DOMAIN . TFO_INDEX ?>";
</script>
</body>

</html>