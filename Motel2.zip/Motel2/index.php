<?php
session_start();
require_once('./mvc/Middleware.php');
new MiddleWare();
